﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Inventory.Data
{
    public class Warehouse
    {
        [Key]
        public int WarehouseId { get; set; }

        [Column(TypeName = "nvarchar(255)")]
        public string Address { get; set; }

        [ForeignKey("Administrator")]
        public int AdministratorAdminId { get; set; }
        [ForeignKey("CompanyName")]
        public string CompanyNameWareHouse { get; set; }
    }
}
