﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Inventory.Data
{
    public class User
    {
        [Key]
        public int UserId { get; set; }

        [Column(TypeName = "nvarchar(256)")]
        public string Name { get; set; }

        [Column(TypeName = "nvarchar(256)")]
        public string Password { get; set; }

        [Column(TypeName = "nvarchar(255)")]
        public string CompanyName { get; set; }

        [Column(TypeName = "nvarchar(50)")]
        public string EmailAddress { get; set; }

        [Column(TypeName = "nvarchar(20)")]
        public string PhoneNumber { get; set; }

        [Column(TypeName = "bit")]
        public bool IsConfirmed { get; set; }

        [Column(TypeName = "nvarchar(50)")]
        public string Role { get; set; }
    }
}
