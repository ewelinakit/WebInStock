﻿using Microsoft.EntityFrameworkCore;

namespace Inventory.Data
{
    public class InventoryDataContext : DbContext
    {
        public InventoryDataContext(DbContextOptions<InventoryDataContext> options) :
              base(options)
        {
        }

        public InventoryDataContext() { }

        public virtual DbSet<User> Users { get; set; }
        public virtual DbSet<Warehouse> Warehouses { get; set; }
        public virtual DbSet<Goods> Goods { get; set; }
    }
}
