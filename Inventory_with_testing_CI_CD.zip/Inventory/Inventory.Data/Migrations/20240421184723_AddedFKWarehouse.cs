﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Inventory.Data.Migrations
{
    /// <inheritdoc />
    public partial class AddedFKWarehouse : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "WarehouseId",
                table: "Goods",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Goods_WarehouseId",
                table: "Goods",
                column: "WarehouseId");

            migrationBuilder.AddForeignKey(
                name: "FK_Goods_Warehouses_WarehouseId",
                table: "Goods",
                column: "WarehouseId",
                principalTable: "Warehouses",
                principalColumn: "WarehouseId",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Goods_Warehouses_WarehouseId",
                table: "Goods");

            migrationBuilder.DropIndex(
                name: "IX_Goods_WarehouseId",
                table: "Goods");

            migrationBuilder.DropColumn(
                name: "WarehouseId",
                table: "Goods");
        }
    }
}
