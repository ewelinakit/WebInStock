using Xunit;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Inventory.Controllers;
using Inventory.Data;
using Inventory.Models;
using Inventory.Models.Dto;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using System.Security.Claims;
using Inventory.Services;
using Moq;

namespace TestProject3
{
    public class AdminDashboardControllerTests
    {
        private readonly AdminDashboardController _controller;
        private readonly InventoryDataContext _context;

        public AdminDashboardControllerTests()
        {
            var options = new DbContextOptionsBuilder<InventoryDataContext>()
                .UseInMemoryDatabase(databaseName: "TestDb_" + Guid.NewGuid().ToString())
                .Options;
            _context = new InventoryDataContext(options);
            _context.Database.EnsureDeleted();
            _context.Database.EnsureCreated();

            SeedDatabase();

            _controller = new AdminDashboardController(_context, new Mock<IPasswordService>().Object);
            SetupControllerContext();
        }

        private void SeedDatabase()
        {
            _context.Warehouses.Add(new Warehouse { WarehouseId = 1, CompanyNameWareHouse = "Sample Company", Address = "123 Main St" });
            _context.Users.Add(
                new User
                {
                    UserId = 1,
                    Name = "John Doe",
                    Role = "Admin",
                    IsConfirmed = false,
                    CompanyName = "Sample Company",
                    EmailAddress = "john.doe@example.com",
                    Password = "securePassword123",
                    PhoneNumber = "123-456-7890"
                });
            _context.SaveChanges();
        }

        private void SetupControllerContext()
        {
            var user = new ClaimsPrincipal(new ClaimsIdentity(new Claim[]
            {
                new Claim(ClaimTypes.NameIdentifier, "1"),
                new Claim("CompanyName", "Sample Company")
            }, "TestAuthentication"));

            _controller.ControllerContext = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext { User = user }
            };
        }

        [Fact]
        public async Task GoodsWarehouses_ReturnsViewResult_WithWarehouseList()
        {
            // Act
            var result = await _controller.GoodsWarehouses();

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsType<List<WarehouseDto>>(viewResult.Model);
            Assert.Single(model); 
        }

        [Fact]
        public async Task AddGoods_ReturnsViewResult_WithDefaultGoods()
        {
            // Act
            var result = _controller.AddGoods(1) as ViewResult;

            // Assert
            var model = Assert.IsType<GoodsDto>(result.Model);
            Assert.Equal("Spice", model.Name); 
        }

        [Fact]
        public async Task UpdateAdmin_UpdatesAndRedirects()
        {
            // Arrange
            var goodsDto = new GoodsDto
            {
                Name = "New Spice",
                Category = "Drugs",
                Subcategory = "Heavy",
                Description = "Updated stuff",
                Quantity = 100,
                Price = 150,
                PhotoUrl = "newphoto.jpg",
                WarehouseId = 1
            };

            // Act
            var result = await _controller.AddGoods(goodsDto);

            // Assert
            Assert.IsType<RedirectToActionResult>(result);
            var redirectToActionResult = (RedirectToActionResult)result;
            Assert.Equal("GoodsWarehouses", redirectToActionResult.ActionName);
        }
    }
}
