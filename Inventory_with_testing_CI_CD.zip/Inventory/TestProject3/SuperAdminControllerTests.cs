using Xunit;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Inventory.Controllers;
using Inventory.Data;
using Inventory.Models;
using Inventory.Models.Dto;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Moq;

namespace TestProject3
{
    public class SuperAdminControllerTests
    {
        private readonly InventoryDataContext _context;
        private SuperAdminController _controller;

        public SuperAdminControllerTests()
        {
            var options = new DbContextOptionsBuilder<InventoryDataContext>()
                .UseInMemoryDatabase(databaseName: "TestDb_" + Guid.NewGuid().ToString())
                .Options;
            _context = new InventoryDataContext(options);
            _context.Database.EnsureDeleted();
            _context.Database.EnsureCreated();

            SetupController();
        }

        private void SetupController()
        {
            _controller = new SuperAdminController(_context);
            var mockTempDataProvider = new Mock<ITempDataProvider>();
            _controller.ControllerContext = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext()
            };
            _controller.TempData = new TempDataDictionary(_controller.ControllerContext.HttpContext, mockTempDataProvider.Object);
        }

        private void SeedDatabase()
        {
            _context.Users.Add(new User
            {
                UserId = 1,
                Name = "John Doe",
                Role = "Admin",
                IsConfirmed = false,
                CompanyName = "Sample Company",
                EmailAddress = "john.doe@example.com",
                Password = "securePassword123",
                PhoneNumber = "123-456-7890"
            });
            _context.SaveChanges();
        }

        [Fact]
        public async Task Index_ReturnsViewResult_WithAListOfAdmins()
        {
            // Arrange
            SeedDatabase();

            // Act
            var result = await _controller.Index();

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsType<List<User>>(viewResult.Model);
            Assert.Single(model);
        }

        [Fact]
        public async Task ConfirmAdmin_UpdatesAdminStatus()
        {
            // Arrange
            SeedDatabase();

            // Act
            var result = await _controller.ConfirmAdmin(1);

            // Assert
            var admin = _context.Users.Find(1);
            Assert.True(admin.IsConfirmed);
            Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Index", (result as RedirectToActionResult).ActionName);
        }

        [Fact]
        public async Task EditAdmin_ReturnsCorrectViewAndModel()
        {
            // Arrange
            SeedDatabase();

            // Act
            var result = await _controller.EditAdmin(1);

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsType<UserDto>(viewResult.Model);
            Assert.Equal(1, model.UserId);
        }

        [Fact]
        public async Task UpdateAdmin_UpdatesAndRedirects()
        {
            // Arrange
            SeedDatabase();
            var adminDto = new UserDto
            {
                UserId = 1,
                Name = "Updated Name",
                Role = "Admin",
                IsConfirmed = true,
                CompanyName = "Updated Company",
                EmailAddress = "updated@example.com",
                Password = "newSecurePassword123",
                PhoneNumber = "987-654-3210"
            };

            // Act
            var result = await _controller.UpdateAdmin(adminDto);

            // Assert
            var updatedAdmin = _context.Users.Find(1);
            Assert.NotNull(updatedAdmin);
            Assert.Equal("Updated Name", updatedAdmin.Name);
            Assert.True(updatedAdmin.IsConfirmed);
            Assert.IsType<RedirectToActionResult>(result);
        }

        [Fact]
        public async Task UpdateAdmin_ReturnsViewWhenModelInvalid()
        {
            // Arrange
            SeedDatabase();
            _controller.ModelState.AddModelError("Name", "Required");
            var adminDto = new UserDto { UserId = 1, Role = "Admin" };

            // Act
            var result = await _controller.UpdateAdmin(adminDto);

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            Assert.Equal("EditAdmin", viewResult.ViewName);
        }
    }
}
