using Xunit;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Inventory.Controllers;
using Inventory.Data;
using Inventory.Models;
using Inventory.Models.Dto;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using System.Security.Claims;
using System.Text.Json;

namespace TestProject3
{
    public class OperatorDashboardControllerTests
    {
        private readonly OperatorDashboardController _controller;
        private readonly InventoryDataContext _context;

        public OperatorDashboardControllerTests()
        {
            var options = new DbContextOptionsBuilder<InventoryDataContext>()
                .UseInMemoryDatabase(databaseName: "TestDb_" + Guid.NewGuid().ToString())
                .Options;
            _context = new InventoryDataContext(options);
            _context.Database.EnsureDeleted();
            _context.Database.EnsureCreated();

            SeedDatabase();

            _controller = new OperatorDashboardController(_context);
            SetupControllerContext("Sample Company");
        }

        private void SeedDatabase()
        {
            var company = "Sample Company";
            _context.Warehouses.AddRange(
                new Warehouse { WarehouseId = 1, CompanyNameWareHouse = company, Address = "123 Main St" },
                new Warehouse { WarehouseId = 2, CompanyNameWareHouse = company, Address = "456 Second St" }
            );
            _context.Goods.AddRange(
                new Goods { GoodsId = 1, Name = "Item 1", Category = "Category 1", WarehouseId = 1, Quantity = 100, Price = 10.00m, Description = "sasasa", PhotoUrl ="photourl", Subcategory= " sdsdsd" },
                new Goods { GoodsId = 2, Name = "Item 2", Category = "Category 2", WarehouseId = 1, Quantity = 200, Price = 20.00m, Description = "sasasa", PhotoUrl = "photourl", Subcategory = " sdsdsd" }
            );
            _context.SaveChanges();
        }

        private void SetupControllerContext(string companyName)
        {
            var user = new ClaimsPrincipal(new ClaimsIdentity(new Claim[]
            {
                new Claim(ClaimTypes.NameIdentifier, "1"),
                new Claim("CompanyName", companyName)
            }, "TestAuthentication"));

            _controller.ControllerContext = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext { User = user }
            };
        }

        [Fact]
        public async Task SelectWarehouse_ReturnsViewResult_WithWarehouseList()
        {
            // Act
            var result = await _controller.SelectWarehouse();

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<IEnumerable<WarehouseDto>>(viewResult.Model);
            Assert.NotEmpty(model); 
        }

        [Fact]
        public async Task ManageGoods_ReturnsViewResult_WithGoodsList()
        {
            // Act
            var result = await _controller.ManageGoods(1);

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<IEnumerable<GoodsDto>>(viewResult.Model);
            Assert.NotEmpty(model); 
        }


        [Fact]
        public async Task UpdateGoods_ReturnsJsonResult_WithSuccess()
        {
            int goodsId = 1;
            int newQuantity = 150;
            decimal newPrice = 15.00m;
            var result = await _controller.UpdateGoods(goodsId, newQuantity, newPrice) as JsonResult;
            Assert.NotNull(result);

            var data = JsonSerializer.Deserialize<Dictionary<string, JsonElement>>(JsonSerializer.Serialize(result.Value));

            bool success = data["success"].GetBoolean();
            string message = data["message"].GetString();

            Assert.True(success);
            Assert.Equal("Goods updated successfully", message);
        }

        [Fact]
        public async Task TransferGoods_ReturnsJsonResult_WithSuccess()
        {
            var transferDto = new GoodsTransferDto
            {
                SourceWarehouseId = 1,
                DestinationWarehouseId = 2,
                GoodsId = 1,
                Quantity = 50
            };

            var result = await _controller.TransferGoods(transferDto) as JsonResult;
            Assert.NotNull(result);

            var data = JsonSerializer.Deserialize<Dictionary<string, JsonElement>>(JsonSerializer.Serialize(result.Value));

            bool success = data["success"].GetBoolean();
            string message = data["message"].GetString();

            Assert.True(success);
            Assert.Equal("Goods transferred successfully.", message);
        }


    [Fact]
        public async Task GetGoods_ReturnsJsonResult_WithGoodsList()
        {
            // Act
            var result = await _controller.GetGoods(1);

            // Assert
            var jsonResult = Assert.IsType<JsonResult>(result);
            var goodsList = Assert.IsAssignableFrom<IEnumerable<dynamic>>(jsonResult.Value);
            Assert.NotEmpty(goodsList);
        }
    }
}
