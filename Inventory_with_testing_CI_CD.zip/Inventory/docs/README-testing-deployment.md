# Матеріали до завдання: тестування та CI/CD

- `test-plan.md` — ручні, smoke, нефункціональні та автоматизовані перевірки.
- `deployment-plan.md` — CI/CD, середовища, моніторинг, резервне копіювання та відкат.
- `../.github/workflows/ci.yml` — GitHub Actions для .NET 8.

Команда локальної перевірки з папки, де лежить `Inventory.sln`:

```bash
dotnet restore Inventory.sln
dotnet build Inventory.sln --configuration Release --no-restore
dotnet test Inventory.sln --configuration Release --no-build
```

Workflow підготовлено під структуру з архіву. Фактичне виконання тестів потрібно підтвердити локально або у GitHub Actions; у середовищі підготовки немає встановленого .NET SDK.
