﻿namespace Inventory.Models.Dto
{
    public class GoodsTransferDto
    {
        public int SourceWarehouseId { get; set; }
        public int DestinationWarehouseId { get; set; }
        public int GoodsId { get; set; }
        public int Quantity { get; set; }
    }

}
