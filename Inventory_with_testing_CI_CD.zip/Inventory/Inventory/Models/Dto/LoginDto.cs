﻿using System.ComponentModel.DataAnnotations;

namespace Inventory.Models.Dto
{
    public class LoginDto
    {
        [Required(ErrorMessage = "Ім'я користувача обов'язкове.")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Пароль обов'язковий.")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }

}
