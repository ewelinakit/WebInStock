﻿namespace Inventory.Models.Dto
{
    public class WarehouseDto
    {
        public int WarehouseId { get; set; }
        public string Address { get; set; }
        public int AdministratorAdminId { get; set; }
        public string CompanyNameWareHouse { get; set; }
    }
}
