﻿namespace Inventory.Models.Dto
{
    public class GoodsDto
    {
        public int GoodsId { get; set; }
        public string Name { get; set; }
        public string Category { get; set; }
        public string Subcategory { get; set; }
        public string Description { get; set; }
        public int Quantity { get; set; }
        public decimal Price { get; set; }
        public string PhotoUrl { get; set; }
        public int WarehouseId { get; set; }
    }
}
