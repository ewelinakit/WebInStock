﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Inventory.Data;
using Inventory.Models.Dto;
using System.Linq;
using System.Threading.Tasks;
using System.Security.Claims;

namespace Inventory.Controllers
{
    [Authorize(Roles = "Operator")]
    public class OperatorDashboardController : Controller
    {
        private readonly InventoryDataContext _context;

        public OperatorDashboardController(InventoryDataContext context)
        {
            _context = context;
        }

        #region ManageGoods
        [HttpGet("SelectWarehouse")]
        public async Task<IActionResult> SelectWarehouse()
        {
            var companyName = User.Claims.FirstOrDefault(c => c.Type == "CompanyName")?.Value;
            var warehouses = await _context.Warehouses
                .Where(w => w.CompanyNameWareHouse == companyName)
                .ToListAsync();

            return View(warehouses.Select(w => new WarehouseDto
            {
                WarehouseId = w.WarehouseId,
                Address = w.Address,
                CompanyNameWareHouse = w.CompanyNameWareHouse
            }));
        }

        [HttpGet("ManageGoods/{warehouseId}")]
        public async Task<IActionResult> ManageGoods(int warehouseId)
        {
            var companyName = User.Claims.FirstOrDefault(c => c.Type == "CompanyName")?.Value;
            var goods = await _context.Goods
                .Include(g => g.Warehouse)
                .Where(g => g.Warehouse.WarehouseId == warehouseId && g.Warehouse.CompanyNameWareHouse == companyName)
                .ToListAsync();

            var sortedGoods = goods.OrderBy(g => g.Category).ToList(); 

            return View(sortedGoods.Select(g => new GoodsDto
            {
                GoodsId = g.GoodsId,
                Name = g.Name,
                Category = g.Category,
                Subcategory = g.Subcategory,
                Description = g.Description,
                Quantity = g.Quantity,
                Price = g.Price,
                PhotoUrl = g.PhotoUrl,
                WarehouseId = g.WarehouseId
            }));
        }

        [HttpPost("UpdateGoods")]
        public async Task<IActionResult> UpdateGoods(int goodsId, int newQuantity, decimal newPrice)
        {
            var goods = await _context.Goods.FindAsync(goodsId);
            if (goods == null)
            {
                return Json(new { success = false, message = "Goods not found" });
            }

            goods.Quantity = newQuantity;
            goods.Price = newPrice;
            await _context.SaveChangesAsync();
            return Json(new { success = true, message = "Goods updated successfully" });
        }
        #endregion

        #region TransferGoods
        [HttpGet("TransferGoods")]
        public async Task<IActionResult> TransferGoods()
        {
            var companyName = User.Claims.FirstOrDefault(c => c.Type == "CompanyName")?.Value;
            var warehouses = await _context.Warehouses
                .Where(w => w.CompanyNameWareHouse == companyName)
                .ToListAsync();

            return View(warehouses.Select(w => new WarehouseDto
            {
                WarehouseId = w.WarehouseId,
                Address = w.Address
            }));
        }

        [HttpPost("TransferGoods")]
        public async Task<IActionResult> TransferGoods([FromBody] GoodsTransferDto transferDto)
        {
            var companyName = User.FindFirstValue("CompanyName");

            if (string.IsNullOrEmpty(companyName))
            {
                return Json(new { success = false, message = "Operator's company not found." });
            }

            var sourceWarehouse = await _context.Warehouses
                .SingleOrDefaultAsync(w => w.WarehouseId == transferDto.SourceWarehouseId && w.CompanyNameWareHouse == companyName);

            var destinationWarehouse = await _context.Warehouses
                .SingleOrDefaultAsync(w => w.WarehouseId == transferDto.DestinationWarehouseId && w.CompanyNameWareHouse == companyName);

            if (sourceWarehouse == null || destinationWarehouse == null)
            {
                return Json(new { success = false, message = "Source or destination warehouse not found or not available in your company." });
            }

            if (transferDto.SourceWarehouseId == transferDto.DestinationWarehouseId)
            {
                return Json(new { success = false, message = "The source and destination warehouses cannot be the same." });
            }

            var goods = await _context.Goods
                .SingleOrDefaultAsync(g => g.GoodsId == transferDto.GoodsId && g.WarehouseId == sourceWarehouse.WarehouseId);

            if (goods == null)
            {
                return Json(new { success = false, message = "Goods not found in source warehouse." });
            }

            if (transferDto.Quantity <= 0 || goods.Quantity < transferDto.Quantity)
            {
                return Json(new { success = false, message = "Invalid quantity." });
            }

            var matchingGoodsInDestination = await _context.Goods
                .FirstOrDefaultAsync(g => g.Name == goods.Name && g.Category == goods.Category && g.WarehouseId == destinationWarehouse.WarehouseId);

            if (matchingGoodsInDestination != null)
            {
                matchingGoodsInDestination.Quantity += transferDto.Quantity;
            }
            else
            {
                var newGoods = new Goods
                {
                    Name = goods.Name,
                    Category = goods.Category,
                    Subcategory = goods.Subcategory,
                    Description = goods.Description,
                    Price = goods.Price,
                    PhotoUrl = goods.PhotoUrl,
                    Quantity = transferDto.Quantity,
                    WarehouseId = destinationWarehouse.WarehouseId
                };
                _context.Goods.Add(newGoods);
            }

            if (goods.Quantity == transferDto.Quantity)
            {
                _context.Goods.Remove(goods);
            }
            else
            {
                goods.Quantity -= transferDto.Quantity;
            }

            try
            {
                await _context.SaveChangesAsync();
                return Json(new { success = true, message = "Goods transferred successfully." });
            }
            catch (DbUpdateException ex)
            {
                return Json(new { success = false, message = "An error occurred while saving the entity changes. See the inner exception for details." });
            }
        }



        [HttpGet("GetGoods")]
        public async Task<IActionResult> GetGoods(int warehouseId)
        {
            var goods = await _context.Goods
                .Where(g => g.WarehouseId == warehouseId)
                .ToListAsync();

            return Json(goods.Select(g => new { goodsId = g.GoodsId, name = g.Name, quantity = g.Quantity }));
        }

        #endregion
    }
}
