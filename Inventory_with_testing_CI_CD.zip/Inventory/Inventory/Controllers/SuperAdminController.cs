﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Inventory.Data;
using Inventory.Models;
using Inventory.Models.Dto;

namespace Inventory.Controllers
{
    [Authorize(Roles = "SuperAdmin")]
    public class SuperAdminController : Controller
    {
        private readonly InventoryDataContext _context;

        public SuperAdminController(InventoryDataContext context)
        {
            _context = context;
        }
        [HttpGet("Index/{showUnconfirmed?}")]
        public async Task<IActionResult> Index(bool showUnconfirmed = false)
        {
            var adminsQuery = _context.Users.Where(u => u.Role == "Admin");
            if (showUnconfirmed)
            {
                adminsQuery = adminsQuery.Where(u => !u.IsConfirmed);
            }

            var admins = await adminsQuery.ToListAsync();
            return View(admins);
        }
        [HttpPost("ConfirmAdmin")]
        public async Task<IActionResult> ConfirmAdmin(int adminId)
        {
            var admin = await _context.Users.FirstOrDefaultAsync(u => u.UserId == adminId && u.Role == "Admin");
            if (admin != null)
            {
                admin.IsConfirmed = true;
                _context.Update(admin);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Admin confirmed successfully.";
            }
            else
            {
                TempData["ErrorMessage"] = "Admin not found.";
            }
            return RedirectToAction(nameof(Index));
        }
        [HttpGet("EditAdmin/{adminId}")]
        public async Task<IActionResult> EditAdmin(int adminId)
        {
            var admin = await _context.Users.FirstOrDefaultAsync(u => u.UserId == adminId && u.Role == "Admin");
            if (admin == null)
            {
                TempData["ErrorMessage"] = "Admin not found.";
                return RedirectToAction(nameof(Index));
            }

            var adminDto = new UserDto
            {
                UserId = admin.UserId,
                Name = admin.Name,
                Password = admin.Password,
                EmailAddress = admin.EmailAddress,
                PhoneNumber = admin.PhoneNumber,
                CompanyName = admin.CompanyName,
                IsConfirmed = admin.IsConfirmed,
                Role = admin.Role
            };

            return View(adminDto);
        }

        [HttpPost("UpdateAdmin")]
        public async Task<IActionResult> UpdateAdmin(UserDto adminDto)
        {
            if (!ModelState.IsValid)
            {
                return View("EditAdmin", adminDto);
            }

            var admin = await _context.Users.FirstOrDefaultAsync(u => u.UserId == adminDto.UserId && u.Role == "Admin");
            if (admin == null)
            {
                TempData["ErrorMessage"] = "Admin not found.";
                return RedirectToAction(nameof(Index));
            }

            admin.Name = adminDto.Name;
            admin.EmailAddress = adminDto.EmailAddress;
            admin.PhoneNumber = adminDto.PhoneNumber;
            admin.CompanyName = adminDto.CompanyName;
            admin.IsConfirmed = adminDto.IsConfirmed;

            _context.Update(admin);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Admin updated successfully.";
            return RedirectToAction(nameof(Index));
        }

    }
}
