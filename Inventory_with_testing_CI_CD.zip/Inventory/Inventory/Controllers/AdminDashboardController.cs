﻿using Inventory.Data;
using Inventory.Models.Dto;
using Inventory.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace Inventory.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AdminDashboardController : Controller
    {
        private readonly InventoryDataContext _context;
        private readonly IPasswordService _passwordService;

        public AdminDashboardController(InventoryDataContext context, IPasswordService passwordService)
        {
            _context = context;
            _passwordService = passwordService;
        }
        [HttpGet("GoodsWarehouses")]
        public async Task<IActionResult> GoodsWarehouses()
        {
            var adminCompanyName = User.FindFirstValue("CompanyName");
            var warehouses = await _context.Warehouses
                                           .Where(w => w.CompanyNameWareHouse == adminCompanyName)
                                           .Select(w => new WarehouseDto
                                           {
                                               WarehouseId = w.WarehouseId,
                                               Address = w.Address,
                                               AdministratorAdminId = w.AdministratorAdminId,
                                               CompanyNameWareHouse = w.CompanyNameWareHouse
                                           })
                                           .ToListAsync();
            return View(warehouses);
        }


        #region MethodGoods

        [HttpGet("AddGoods/{warehouseId}")]
        public IActionResult AddGoods(int warehouseId)
        {
            var model = new GoodsDto {
                Name = "Spice",
                Category = "Drugs",
                Subcategory = "Heavy",
                Description = "Cool stuff",
                Quantity = 10,
                Price = 120,
                PhotoUrl = "22323edsdsd",
                WarehouseId = warehouseId };
            return View(model);
        }

        [HttpPost("AddGoods/{warehouseId}")]
        public async Task<IActionResult> AddGoods(GoodsDto goodsDto)
        {
            if (!ModelState.IsValid)
            {
                return View(goodsDto);
            }

            var goods = new Goods
            {
                Name = goodsDto.Name,
                Category = goodsDto.Category,
                Subcategory = goodsDto.Subcategory,
                Description = goodsDto.Description,
                Quantity = goodsDto.Quantity,
                Price = goodsDto.Price,
                PhotoUrl = goodsDto.PhotoUrl,
                WarehouseId = goodsDto.WarehouseId
            };

            _context.Goods.Add(goods);
            await _context.SaveChangesAsync();
            return RedirectToAction("GoodsWarehouses");
        }

        [HttpGet("ViewGoods/{warehouseId:int}")]
        public async Task<IActionResult> ViewGoods(int warehouseId)
        {
            var goodsInWarehouse = await _context.Goods
                .Where(g => g.WarehouseId == warehouseId)
                .Select(g => new GoodsDto
                {
                    GoodsId = g.GoodsId,
                    Name = g.Name,
                    Category = g.Category,
                    Subcategory = g.Subcategory,
                    Description = g.Description,
                    Quantity = g.Quantity,
                    Price = g.Price,
                    PhotoUrl = g.PhotoUrl,
                    WarehouseId = g.WarehouseId
                }).ToListAsync();

            return View("ViewGoods", goodsInWarehouse);
        }

        [HttpPost("DeleteGoods")]
        public async Task<IActionResult> DeleteGoods(int id)
        {
            var goods = await _context.Goods.FindAsync(id);
            if (goods == null)
            {
                TempData["Error"] = "Goods not found";
                return RedirectToAction("ViewGoods", new { warehouseId = -1 });  
            }

            int warehouseId = goods.WarehouseId;  
            _context.Goods.Remove(goods);
            await _context.SaveChangesAsync();
            TempData["Success"] = "Goods deleted successfully";
            return RedirectToAction("ViewGoods", new { warehouseId = warehouseId });  
        }


        #endregion

        #region MethodWareHouse
        [HttpGet("AddWarehouse")]
        public IActionResult AddWarehouse()
        {
            var userIdString = User.FindFirstValue(ClaimTypes.NameIdentifier);
            int userId;

            if (int.TryParse(userIdString, out userId))
            {
                var user = _context.Users.FirstOrDefault(u => u.UserId == userId && u.Role == "Admin");
                if (user != null)
                {
                    var model = new WarehouseDto { AdministratorAdminId = userId, CompanyNameWareHouse = user.CompanyName};
                    return View(model);
                }
                else
                {
                    TempData["Error"] = "You must be an admin to add a warehouse.";
                    return RedirectToAction("Index", "Home"); 
                }
            }
            else
            {
                TempData["Error"] = "There was a problem retrieving your user information.";
                return RedirectToAction("Index", "Home"); 
            }
        }


        [HttpPost("AddWarehouse")]
        public async Task<IActionResult> AddWarehouse(WarehouseDto warehouseDto)
        {
            if (!ModelState.IsValid)
            {
                return View(warehouseDto);
            }

            var user = await _context.Users
                .AsNoTracking()
                .FirstOrDefaultAsync(u => u.UserId == warehouseDto.AdministratorAdminId && u.Role == "Admin");

            if (user == null)
            {
                ModelState.AddModelError("", "Only Admin users can add warehouses.");
                return View(warehouseDto);
            }

            var warehouse = new Warehouse
            {
                Address = warehouseDto.Address,
                AdministratorAdminId = warehouseDto.AdministratorAdminId,
                CompanyNameWareHouse = warehouseDto.CompanyNameWareHouse    
            };

            _context.Warehouses.Add(warehouse);
            await _context.SaveChangesAsync();
            return RedirectToAction("GoodsWarehouses");
        }

        [HttpPost("DeleteWarehouse")]
        public async Task<IActionResult> DeleteWarehouse(int id)
        {
            var warehouse = await _context.Warehouses.FindAsync(id);
            if (warehouse == null)
            {
                TempData["Error"] = "Warehouse not found";
                return RedirectToAction("GoodsWarehouses");
            }

            _context.Warehouses.Remove(warehouse);
            await _context.SaveChangesAsync();
            TempData["Success"] = "Warehouse successfully deleted";
            return RedirectToAction("GoodsWarehouses");
        }

        [HttpGet("EditWarehouse/{id:int}")]
        public async Task<IActionResult> EditWarehouse(int id)
        {
            var warehouse = await _context.Warehouses
                                          .AsNoTracking()
                                          .Select(w => new WarehouseDto
                                          {
                                              WarehouseId = w.WarehouseId,
                                              Address = w.Address,
                                              AdministratorAdminId = w.AdministratorAdminId
                                          })
                                          .FirstOrDefaultAsync(w => w.WarehouseId == id);
            if (warehouse == null)
            {
                TempData["Error"] = "Warehouse not found";
                return RedirectToAction("GoodsWarehouses");
            }

            return View(warehouse);
        }

        [HttpPost("EditWarehouse/{id:int}")]
        public async Task<IActionResult> EditWarehouse(int id, WarehouseDto warehouseDto)
        {
            if (!ModelState.IsValid)
            {
                return View(warehouseDto);
            }

            var warehouse = await _context.Warehouses
                                          .FirstOrDefaultAsync(w => w.WarehouseId == id);
            if (warehouse == null)
            {
                TempData["Error"] = "Warehouse not found";
                return RedirectToAction("GoodsWarehouses");
            }

            warehouse.Address = warehouseDto.Address;

            await _context.SaveChangesAsync();
            TempData["Success"] = "Warehouse successfully updated";
            return RedirectToAction("GoodsWarehouses");
        }
        #endregion

        #region MethodOperators
        [HttpGet("Operators")]
        public async Task<IActionResult> Operators()
        {
            var adminCompanyName = User.Claims.FirstOrDefault(c => c.Type == "CompanyName")?.Value;
            var operatorUsers = await _context.Users
                .Where(u => u.CompanyName == adminCompanyName && u.Role == "Operator")
                .ToListAsync();

            var operatorDtos = operatorUsers.Select(u => new UserDto
            {
                UserId = u.UserId,
                Name = u.Name,
                CompanyName = u.CompanyName,
                EmailAddress = u.EmailAddress,
                PhoneNumber = u.PhoneNumber,
                IsConfirmed = u.IsConfirmed,
                Role = u.Role
            }).ToList();

            return View(operatorDtos);
        }


        [HttpGet("AddOperator")]
        public IActionResult AddOperator()
        {
            return View();
        }
        [HttpPost("AddOperator")]
        public async Task<IActionResult> AddOperator(UserDto userDto)
        {
            if (!ModelState.IsValid)
            {
                return View(userDto);
            }

            var user = new User
            {
                Name = userDto.Name,
                EmailAddress = userDto.EmailAddress,
                PhoneNumber = userDto.PhoneNumber,
                Password = _passwordService.HashPassword(userDto.Password),
                CompanyName = User.Claims.FirstOrDefault(c => c.Type == "CompanyName")?.Value, 
                Role = "Operator", 
                IsConfirmed = true 
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            TempData["Success"] = "Operator added successfully.";
            return RedirectToAction("Operators");
        }

        [HttpGet("EditOperator/{id}")]
        public async Task<IActionResult> EditOperator(int id)
        {
            var userDto = await _context.Users
                .Where(u => u.UserId == id && u.Role == "Operator")
                .Select(u => new UserDto
                {
                    UserId = u.UserId,
                    Name = u.Name,
                    EmailAddress = u.EmailAddress,
                    PhoneNumber = u.PhoneNumber,
                    CompanyName = u.CompanyName,
                    Role = u.Role
                }).FirstOrDefaultAsync();

            if (userDto == null)
            {
                TempData["Error"] = "Operator not found";
                return RedirectToAction("Operators");
            }

            return View(userDto);
        }

        [HttpPost("EditOperator/{id}")]
        public async Task<IActionResult> EditOperator(UserDto userDto)
        {
            if (string.IsNullOrEmpty(userDto.Password))
            {
                ModelState["Password"].Errors.Clear();

                if (!ModelState["Password"].Errors.Any())
                {
                    ModelState.Remove("Password");
                }
            }

            if (!ModelState.IsValid)
            {
                return View(userDto);
            }

            var user = await _context.Users.FindAsync(userDto.UserId);
            if (user == null)
            {
                TempData["Error"] = "Operator not found";
                return RedirectToAction("Operators");
            }

            user.Name = userDto.Name;
            user.EmailAddress = userDto.EmailAddress;
            user.PhoneNumber = userDto.PhoneNumber;

            if (!string.IsNullOrWhiteSpace(userDto.Password))
            {
                user.Password = _passwordService.HashPassword(userDto.Password);
            }

            await _context.SaveChangesAsync();

            TempData["Success"] = "Operator updated successfully";
            return RedirectToAction("Operators");
        }



        [HttpPost("DeleteOperator")]
        public async Task<IActionResult> DeleteOperator(int id)
        {
            var user = await _context.Users.FindAsync(id);
            if (user == null || user.Role != "Operator")
            {
                TempData["Error"] = "Operator not found";
                return RedirectToAction("Operators");
            }

            _context.Users.Remove(user);
            await _context.SaveChangesAsync();

            TempData["Success"] = "Operator deleted successfully";
            return RedirectToAction("Operators");
        }

        #endregion
    }
}
