﻿using Inventory.Data;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Linq;
using System.Threading.Tasks;
using Inventory.Models.Dto;
using Inventory.Services;

namespace Inventory.Controllers
{
    [Controller]
    [Route("[controller]")]
    public class AuthController : Controller
    {
        private readonly InventoryDataContext _context;
        private readonly IPasswordService _passwordService;

        public AuthController(InventoryDataContext context,  IPasswordService passwordService)
        {
            _context = context;
            _passwordService = passwordService;
        }

        [HttpGet("login")]
        public IActionResult Login() => View();

        [HttpGet("register")]
        public IActionResult Register() => View();

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromForm] LoginDto loginDto)
        {
            var user = _context.Users.FirstOrDefault(u => u.Name == loginDto.Name);

            string generalLoginError = "Неправильне ім'я користувача або пароль.";

            if (user == null || !_passwordService.VerifyPassword(attemptedPassword: loginDto.Password, user.Password))
            {
                ModelState.AddModelError(string.Empty, generalLoginError);
                return View(loginDto);
            }

            if (user.Role == "Admin" && !user.IsConfirmed)
            {
                ModelState.AddModelError(string.Empty, "Ваш акаунт адміністратора ще не підтверджено.");
                return View(loginDto);
            }

            var claims = new List<Claim>
            {
                 new Claim(ClaimTypes.Name, user.Name),
                 new Claim(ClaimTypes.Role, user.Role),
                 new Claim(ClaimTypes.NameIdentifier, user.UserId.ToString()),
                 new Claim("CompanyName", user.CompanyName)
            };

            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            var principal = new ClaimsPrincipal(identity);

            await HttpContext.SignInAsync(principal);
            return RedirectToAction("Index", "Home");
        }


        [HttpPost("register")]
        public async Task<IActionResult> Register([FromForm] UserDto userDto)
        {
            var existingUser = _context.Users.FirstOrDefault(u => u.Name == userDto.Name);
            if (existingUser != null)
            {
                ModelState.AddModelError(string.Empty, "Користувач вже існує.");
                return View(userDto);
            }

            var user = new User
            {
                Name = userDto.Name,
                Password = _passwordService.HashPassword(userDto.Password),
                EmailAddress = userDto.EmailAddress,
                PhoneNumber = userDto.PhoneNumber,
                CompanyName = userDto.CompanyName,
                Role = "Admin",
                IsConfirmed = false
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            return RedirectToAction("Login", "Auth");
        }



        [HttpPost("logout")]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync();
            return RedirectToAction("Index", "Home");
        }

    }
}
