using Inventory.Data;
using Inventory.Models;
using Inventory.Models.Dto;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Inventory.Services;

public interface IUserService
{
    Task<User> CreateUser(User user);
    Task<User> GetUserById(int userId);
    IEnumerable<User> GetAllUsers();
    Task UpdateUser(User user);
    Task DeleteUser(int userId);

    Task<bool> UserExistsByEmail(string emailAddress);
}
